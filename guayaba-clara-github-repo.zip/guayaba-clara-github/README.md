# Guayaba Clara / Café Claro

Sistema web empresarial para la venta y gestión de café colombiano de origen.

## Descripción del proyecto

**Guayaba Clara** es una aplicación web completa orientada a un negocio de café (finca / tostadora) que permite:

- Catálogo de productos con stock en tiempo real
- Carrito de compras y pedidos en línea
- Registro e inicio de sesión de clientes y administradores
- Panel de administración (inventario, pedidos, métricas, promociones)
- Envío de promociones por WhatsApp (Meta Cloud API)
- Historial de pedidos por usuario
- Gestión de roles (`cliente` / `administrador`)

**Stack tecnológico:**
- Frontend: HTML5, CSS3, JavaScript (vanilla)
- Backend: PHP 8+
- Base de datos: MySQL / MariaDB
- Entorno recomendado: XAMPP

## Estructura del repositorio (ciclo de vida del software)

```
00-ingenieria-de-requerimientos/
01-analisis/
02-diseno/
03-desarrollo/
04-pruebas/
05-implementacion/
```

Cada carpeta contiene la documentación y artefactos correspondientes a esa fase del proyecto **Guayaba Clara**.

## Cómo ejecutar el sistema

Consulta la carpeta `05-implementacion/` o el archivo `README-XAMPP.md` incluido en el código fuente.
